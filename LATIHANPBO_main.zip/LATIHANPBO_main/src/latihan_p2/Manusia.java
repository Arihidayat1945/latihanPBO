/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package latihan_p2;

/**
 *
 * @author Fadhil Ramadhan
 */
public class Manusia {
    String nama;
    int umur;
    
    void isivariabel(String namaManusia, int umurManusia){
        nama=namaManusia;
        umur=umurManusia;
    }
    void printManusia(){
        System.out.println("Nama Manusia:" +nama);
        System.out.println("Umur Manusia:" +umur);
    }
}
